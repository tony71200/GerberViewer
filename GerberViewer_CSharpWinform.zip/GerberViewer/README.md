# GerberViewer — C# WinForms (.NET Framework 4.8)

Cấu trúc theo Spec_CSharpWinform.md mục 7.

## Tạo solution trong Visual Studio

1. **GerberEngine** — Class Library (.NET Framework 4.8), C# 7.3.
   Thêm 5 file trong `GerberEngine/`. Reference: `System.Drawing`. **Không** reference `System.Windows.Forms` (NFR-004).
2. **GerberViewer** — Windows Forms App (.NET Framework 4.8), **Platform target: x64** (NFR-002).
   Thêm 4 file trong `GerberViewer/` + `app.manifest` (Project Properties → Application → Manifest).
   Reference project `GerberEngine`.
3. Build & chạy. Kéo-thả file `.gtl/.gts/.gto/...` vào cửa sổ.

## Sử dụng lại engine ngoài WinForms

```csharp
var engine = new GerberEngine.GerberEngineFacade();
engine.LoadLayer("board.gtl");
engine.ExportCombinedPng(new GerberEngine.RenderOptions { Dpi = 1200, Mode = GerberEngine.ColorMode.BinaryMask }, "out.png");
```
