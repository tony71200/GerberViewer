# TÀI LIỆU ĐẶC TẢ KỸ THUẬT (SPECIFICATION – Spec_CSharpWinform.md)
## GERBER VIEWER & PNG CONVERTER — C# / WINFORMS (.NET FRAMEWORK 4.8)

Phiên bản: 1.0 · Ngày: 2026-07-17 · Thay thế: Spec.md (Python/PyQt5)
Tham chiếu UI/UX: chức năng tương đương https://onlinegerberviewer.com/

---

## 1. MỤC TIÊU (BR — Business Requirements)

| ID | Mô tả |
|----|-------|
| BR-001 | Ứng dụng desktop Windows cho phép mở, xem, cấu hình và chuyển đổi file Gerber (RS-274X, Gerber X2) sang ảnh PNG chất lượng cao. |
| BR-002 | Trải nghiệm tương đương Online Gerber Viewer: kéo-thả nhiều file, danh sách lớp có bật/tắt + đổi màu, canvas zoom/pan, hiển thị tọa độ chuột theo mm/inch, render realistic. |
| BR-003 | Lõi xử lý (GerberEngine) tách khỏi UI, đóng gói thành class library có API công khai để tái sử dụng (console, service, app khác). |

## 2. CÔNG NGHỆ BẮT BUỘC

- Ngôn ngữ: **C# 7.3** (mức tối đa .NET Framework 4.8 hỗ trợ mặc định — không dùng record, target-typed `new`, switch expression nâng cao của C# 8+).
- UI: **Windows Forms (.NET Framework 4.8)**, render bằng **GDI+ (System.Drawing)**.
- Không phụ thuộc thư viện ngoài: parser và renderer tự viết trong `GerberEngine`.

## 3. YÊU CẦU CHỨC NĂNG (FR)

Ngôn ngữ "phải" (shall) = bắt buộc. Mỗi FR truy vết về BR và truy vết xuôi tới file mã nguồn (mục 8).

### 3.1. Định dạng & đa lớp
- **FR-001** (BR-001): Hệ thống phải parse đầy đủ RS-274X: `FS` (định dạng tọa độ, omit leading zeros), `MO` (MM/IN), `AD` (aperture C/R/O/P), `AM` (aperture macro), `D01/D02/D03`, `G01/G02/G03`, `G36/G37` (region), `LP` (LPD/LPC), `M02`.
- **FR-002** (BR-001): Hệ thống phải đọc thuộc tính Gerber X2 `TF.FileFunction` để tự nhận diện loại lớp; nếu vắng, nhận diện theo phần mở rộng file (.gtl, .gbl, .gts, .gbs, .gto, .gbo, .gko/.gm1) và từ khóa tên file.
- **FR-003** (BR-002): Người dùng phải nạp được nhiều file cùng lúc (multi-select hoặc kéo-thả vào form); mỗi file là một lớp độc lập có: tên, loại lớp, trạng thái hiển thị, màu riêng.
- **FR-004** (BR-002): Người dùng phải bật/tắt từng lớp, đổi màu từng lớp, xóa lớp, và thay đổi thứ tự vẽ.

### 3.2. Lõi đồ họa & khẩu độ
- **FR-005** (BR-001): Engine phải dựng đúng 4 aperture chuẩn (Circle, Rectangle, Obround, Polygon) cho cả flash (D03) và stroke (D01) với đầu nét tròn (round cap/join) cho aperture tròn.
- **FR-006** (BR-001): Engine phải hỗ trợ Aperture Macro (AM) tối thiểu các primitive 1 (circle), 4 (outline), 5 (polygon), 20 (vector line), 21 (center line); primitive chưa hỗ trợ phải suy giảm an toàn về bounding circle và ghi cảnh báo, không được ném exception làm hỏng render.

### 3.3. Tọa độ & đơn vị
- **FR-007** (BR-001): Engine phải tự phát hiện đơn vị (MM/IN) và định dạng tọa độ từ `FS`/`MO`; nội bộ chuẩn hóa toàn bộ về **milimét (double)**.
- **FR-008** (BR-001): `CoordinateTransformer` phải cung cấp: (a) mm → pixel theo DPI (`px = mm / 25.4 * dpi`); (b) ánh xạ hệ tọa độ Gerber (gốc bất kỳ, trục Y hướng lên) sang hệ tọa độ ảnh (gốc top-left, trục Y hướng xuống) dựa trên bounding box hợp nhất + lề cấu hình được, bảo đảm ảnh không bị cắt lẹm.
- **FR-009** (BR-002): UI phải hiển thị tọa độ con trỏ chuột theo đơn vị mm và inch (chuyển ngược pixel màn hình → mm qua transformer) trên StatusStrip.

### 3.4. Cấu hình ảnh đầu ra
- **FR-010** (BR-001): DPI chọn được từ ComboBox: 150 / 300 / 600 / 1200.
- **FR-011** (BR-001): Hai chế độ màu: (1) **Binary Mask** — nét trắng nền đen (đảo được); (2) **Realistic** — phối màu PCB (đồng vàng, solder mask xanh, silkscreen trắng, nền tối).
- **FR-012** (BR-001): Xuất PNG: từng lớp đang chọn (mỗi lớp một file) hoặc gộp toàn bộ lớp hiển thị thành một file.

### 3.5. Phân cực & polygon pour
- **FR-013** (BR-001): Engine phải xử lý `LPD` (vẽ đè) và `LPC` (khoét): đối tượng LPC được vẽ bằng màu nền/trong suốt lên buffer của chính lớp đó trước khi composite lên các lớp khác — không được khoét xuyên lớp dưới.
- **FR-014** (BR-001): Region (G36/G37) phải fill kín bằng `GraphicsPath` (FillMode.Winding), gồm cả contour chứa cung tròn G02/G03 — không rỗng ruột, không mất nét cắt.

### 3.6. UI/UX (WinForms — chi tiết phân cấp ở mục 5)
- **FR-015** (BR-002): Bố cục: ToolStrip trên cùng (Open, DPI, Color Mode, Render, Export); SplitContainer — trái: panel quản lý lớp; phải: canvas preview; StatusStrip dưới cùng (tọa độ, zoom, kích thước bo).
- **FR-016** (BR-002): Canvas phải zoom bằng lăn chuột (neo tại vị trí con trỏ), pan bằng kéo giữ chuột, nút Fit-to-view; dùng control double-buffered, vẽ lại từ bitmap cache (không re-render engine mỗi lần paint).
- **FR-017** (BR-002): Render và export phải chạy nền (`BackgroundWorker`/`Task.Run` + `Invoke`), UI không đóng băng; có báo trạng thái đang render.

## 4. YÊU CẦU PHI CHỨC NĂNG (NFR)

- **NFR-001**: Render 1 lớp ≤ 50.000 primitive ở 600 DPI, bo ≤ 100×100 mm phải hoàn tất ≤ 10 giây trên máy văn phòng (định nghĩa đo được thay cho "nhanh").
- **NFR-002**: Build **x64** bắt buộc (bitmap 1200 DPI bo lớn vượt giới hạn bộ nhớ tiến trình 32-bit).
- **NFR-003**: File Gerber lỗi cú pháp: engine phải trả về danh sách cảnh báo theo dòng, render phần hợp lệ còn lại; không crash.
- **NFR-004**: `GerberEngine.dll` không được tham chiếu `System.Windows.Forms` (chỉ `System.Drawing`) để tái sử dụng ngoài WinForms.

## 5. GIỚI HẠN & PHÂN CẤP ĐẶC BIỆT CỦA WINFORMS 4.8 (ràng buộc thiết kế)

### 5.1. Giới hạn nền tảng phải tuân thủ
1. **GDI+ chỉ chạy CPU, không GPU**: không có canvas vector retained-mode như QGraphicsScene (PyQt5) hay WPF. Chiến lược bắt buộc: render engine → `Bitmap` cache → `OnPaint` chỉ `DrawImage` bitmap theo ma trận zoom/pan. Cấm vẽ lại toàn bộ primitive trong mỗi `Paint`.
2. **Giới hạn Bitmap**: `Bitmap` GDI+ cấp phát liên tục trong RAM (~4 byte/pixel). Bo 300×300 mm @1200 DPI ≈ 14.170×14.170 px ≈ 800 MB → phải kiểm tra kích thước trước khi cấp phát, cảnh báo người dùng, và giới hạn preview ở DPI thấp hơn DPI export.
3. **Flicker**: control mặc định không double-buffered → panel canvas phải là lớp kế thừa `Panel`/`Control` bật `ControlStyles.OptimizedDoubleBuffer | AllPaintingInWmPaint | UserPaint | ResizeRedraw`.
4. **Single UI thread (STA)**: mọi cập nhật control từ thread render phải qua `Invoke/BeginInvoke`. `Bitmap` không thread-safe — bàn giao quyền sở hữu bitmap sau khi render xong, không dùng chung.
5. **DPI scaling màn hình**: khai báo `PerMonitorV2` trong `app.manifest` + `AutoScaleMode.Dpi`; không hard-code kích thước theo pixel màn hình. (DPI màn hình ≠ DPI ảnh xuất.)
6. **MouseWheel**: panel phải có focus mới nhận wheel → canvas control phải `SetStyle(ControlStyles.Selectable)` hoặc hook `MouseWheel` từ form.
7. **Dispose GDI**: `Bitmap`, `Graphics`, `Pen`, `Brush`, `GraphicsPath` là tài nguyên unmanaged — bắt buộc `using`/`Dispose`, đặc biệt khi re-render thay bitmap cache cũ.

### 5.2. Phân cấp thiết kế UI trong .Designer.cs
1. **Tách file bắt buộc**: `MainForm.Designer.cs` chỉ chứa `InitializeComponent()`, khai báo field control và `Dispose(bool)`. **Không viết logic nghiệp vụ** trong Designer.cs — WinForms Designer sinh lại nội dung `InitializeComponent()` và sẽ xóa code tay.
2. **Control tùy biến không kéo-thả được**: `GerberCanvas` (custom double-buffered control) khai báo trong Designer.cs như control thường (Designer chấp nhận sau khi build); mọi override `OnPaint`, `OnMouseWheel` nằm ở file class riêng `GerberCanvas.cs`.
3. **Thứ tự Dock quyết định layout**: trong `InitializeComponent`, control `Dock.Fill` phải Add **trước**, ToolStrip/StatusStrip Add **sau** (z-order WinForms ngược); sai thứ tự sẽ bị ToolStrip che canvas. Chuẩn hóa: `SplitContainer(Fill)` → `StatusStrip(Bottom)` → `ToolStrip(Top)` theo thứ tự `Controls.Add`.
4. **SuspendLayout/ResumeLayout**: bọc toàn bộ khởi tạo để tránh layout pass thừa.
5. **Event wiring**: gán event handler trong `InitializeComponent` (chuẩn Designer) nhưng thân handler luôn ở `MainForm.cs`.
6. **Không data-binding phức tạp**: danh sách lớp dùng `ListView` (CheckBoxes + owner-draw ô màu) cập nhật thủ công — WinForms không có MVVM binding như WPF.

## 6. GIỚI HẠN CHƯƠNG TRÌNH (giữ từ Spec.md, điều chỉnh)

- Chưa hỗ trợ Excellon/NC Drill (trừ khi lớp khoan được xuất dưới dạng Gerber).
- DPI rất cao trên bo lớn: thời gian render và RAM tăng theo bình phương DPI (giới hạn GDI+ raster — xem 5.1.2).
- Chỉ đọc/hiển thị/xuất ảnh; không chỉnh sửa và không xuất ngược Gerber.
- Bước xoay cung (arc interpolation) xấp xỉ bằng `GraphicsPath.AddArc` — sai số dưới 1 pixel ở DPI ≥ 300.

## 7. KIẾN TRÚC & API GERBERENGINE (class library tái sử dụng)

```
Solution GerberViewer.sln
├── GerberEngine (Class Library, không tham chiếu WinForms)
│   ├── GerberModels.cs          // enum, Aperture, Primitive, GerberLayer
│   ├── GerberParser.cs          // RS-274X / X2 parser → GerberLayer
│   ├── ApertureMacroProcessor.cs// dựng GraphicsPath từ lệnh AM
│   ├── CoordinateTransformer.cs // mm ↔ pixel, Gerber ↔ image space
│   ├── GerberRenderer.cs        // GDI+ raster hóa layer/composite
│   └── GerberEngine.cs          // Facade API công khai
└── GerberViewer (WinForms App x64)
    ├── Program.cs
    ├── MainForm.cs / MainForm.Designer.cs
    └── GerberCanvas.cs          // custom double-buffered canvas
```

API công khai (facade — hợp đồng ổn định để tái sử dụng):

```csharp
public sealed class GerberEngineFacade
{
    IReadOnlyList<GerberLayer> Layers { get; }
    GerberLayer LoadLayer(string filePath);          // parse + auto-detect layer type
    void RemoveLayer(GerberLayer layer);
    void MoveLayer(GerberLayer layer, int newIndex);
    RectangleD GetCombinedBoundsMm();                // bbox hợp nhất các lớp visible
    Bitmap RenderLayer(GerberLayer layer, RenderOptions o);
    Bitmap RenderCombined(RenderOptions o);          // composite các lớp visible
    void ExportLayerPng(GerberLayer l, RenderOptions o, string path);
    void ExportCombinedPng(RenderOptions o, string path);
    event EventHandler<RenderProgressEventArgs> RenderProgress;
}

public sealed class RenderOptions
{
    int Dpi;                    // 150/300/600/1200
    ColorMode Mode;             // BinaryMask | Realistic
    double MarginMm;            // lề quanh bbox
    Color Background;           // nền (Binary: đen; Realistic: nền PCB)
    bool InvertBinary;
}
```

## 8. TRUY VẾT (Traceability)

| Requirement | File hiện thực | Kiểm thử gợi ý |
|---|---|---|
| FR-001, FR-002, FR-007 | GerberParser.cs | Unit test parse file mẫu KiCad/Altium |
| FR-005, FR-006 | GerberModels.cs, ApertureMacroProcessor.cs, GerberRenderer.cs | So sánh ảnh với reference viewer |
| FR-008, FR-009 | CoordinateTransformer.cs | Round-trip mm→px→mm sai số < 1e-6 |
| FR-010–FR-014 | GerberRenderer.cs, GerberEngine.cs | Export mẫu 4 DPI × 2 mode |
| FR-015–FR-017, NFR-002 | MainForm.*, GerberCanvas.cs, Program.cs | Thao tác tay + đo NFR-001 |
| NFR-003 | GerberParser.cs (Warnings) | File lỗi chèn dòng rác |
| NFR-004 | GerberEngine.csproj (references) | Kiểm tra reference khi build |

Không có requirement mồ côi: mọi FR/NFR truy vết về BR-001..003.

## 9. ACCEPTANCE CRITERIA (định dạng hỗn hợp — lý do nêu kèm)

**Gherkin** cho luồng hành vi (phù hợp state/flow):

```gherkin
Scenario: Nạp nhiều lớp và render gộp
  Given người dùng kéo-thả 3 file .gtl, .gts, .gto vào cửa sổ
  When cả 3 lớp ở trạng thái visible và người dùng bấm "Render Preview"
  Then canvas hiển thị ảnh composite theo đúng thứ tự lớp và màu từng lớp
  And StatusStrip hiển thị kích thước bo theo mm

Scenario: Polarity LPC khoét đúng phạm vi lớp
  Given một lớp chứa vùng LPD phủ đồng và sau đó lệnh LPC vẽ đè
  When render lớp đó ở chế độ Binary Mask
  Then vùng LPC hiển thị màu nền (bị khoét) chỉ trong lớp đó
  And các lớp bên dưới trong ảnh composite không bị khoét theo
```

**Checklist** cho hiện diện UI/cấu hình (không phải flow):

- [ ] ToolStrip có đủ: Open, DPI (4 mức), Color Mode (2 mức), Render, Export Selected, Export Combined, Fit.
- [ ] ListView lớp có checkbox visible, ô màu click đổi được, menu chuột phải Remove/Move Up/Down.
- [ ] Zoom bằng wheel neo con trỏ; pan bằng drag; không flicker.
- [ ] Build x64, app.manifest PerMonitorV2.
- [ ] GerberEngine.dll không tham chiếu System.Windows.Forms.
